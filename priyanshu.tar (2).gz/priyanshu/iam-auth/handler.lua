--[[

	@author  Anmol Garg
	@description LUA script to handler of custom plugin
				 logic is placed inside access.execute
				 method of access script.

]]--


local BasePlugin = require "kong.plugins.base_plugin"
local access = require "kong.plugins.iam-auth.core.access"
local IAMAuthHandler = BasePlugin:extend()


function IAMAuthHandler:new()
  IAMAuthHandler.super.new(self, "iam-auth")
end

IAMAuthHandler.PRIORITY = 1500
IAMAuthHandler.VERSION = "1.0.0"


function IAMAuthHandler:access(conf)
  IAMAuthHandler.super.access(self)
  access.execute(conf)
end

return IAMAuthHandler

