--[[

	@author  Rajat Yadav
	@description LUA script to provide schema details for plugin ,
	             it can be changed dynamically from Kong Admin Platform

]]--



return {
  no_consumer = true,
  fields = {

   		http_proxy_enabled_1 = { type = "boolean", default = true },
		plugin_enabled_1 = { type = "boolean", default = true },
		unauthenticated_response_status_code_1 = {type = "number", default = 401},
		unauthenticated_response_headers_1 = { type = "array", default = nil},
		environment_1 = {type = "string", required = true, enum = {"PRODUCTION", "INFRA_1", "INFRA_2", "INFRA_3"}}
    }

  }

