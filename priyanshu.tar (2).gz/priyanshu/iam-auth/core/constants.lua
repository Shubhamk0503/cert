------------------------------------------
-- @author - Anmol Garg
-- @description - File to store static properties
-- which does not depend on environment
------------------------------------------------



CONS = {}

-- proxy constants
CONS.HTTP_PROXY = os.getenv("http_proxy")

-- authentication constants
CONS.SUCCESS_CODE = 200
CONS.UNAUTHENTICATED_CODE = 401
CONS.AUTHORIZATION_HEADER_KEY = "Authorization"
CONS.UNAUTHENTICATED_DEFAULT_RESPONSE = {["authenticated"] = false,["token"] = nil , ["message"]= "user is not authenticated"}
CONS.AUTH_READ_TIMEOUT = 10000


return CONS
