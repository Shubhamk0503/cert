CONS = {}

CONS.PRODUCTION = {}
CONS.PRODUCTION.AUTHENTICATION_URL_TEAM = "http://internalapi-gateway.india.airtel.itm:8080/team-iam/token/v2/validate"
CONS.PRODUCTION.AUTHENTICATION_URL_B2B = "http://ironman-kong.india.airtel.itm/b2b-iam/token/v2/validate"
CONS.PRODUCTION.AUTH_READ_TIMEOUT = 10000

CONS.INFRA_1 = {}
CONS.INFRA_1.AUTHENTICATION_URL_TEAM = "http://internalapi-gateway.india.airtel.itm:8080/team-iam/token/v2/validate"
CONS.INFRA_1.AUTHENTICATION_URL_B2B = "http://ironman-kong.india.airtel.itm/b2b-iam/token/v2/validate"
CONS.INFRA_1.AUTH_READ_TIMEOUT = 10000

CONS.INFRA_2 = {}
CONS.INFRA_2.AUTHENTICATION_URL_TEAM = "http://internalapi-gateway.india.airtel.itm:8080/team-iam/token/v2/validate"
CONS.INFRA_2.AUTHENTICATION_URL_B2B = "http://ironman-kong.india.airtel.itm/b2b-iam/token/v2/validate"
CONS.INFRA_2.AUTH_READ_TIMEOUT = 10000

CONS.INFRA_3 = {}
CONS.INFRA_3.AUTHENTICATION_URL_TEAM = "http://internalapi-gateway.india.airtel.itm:8080/team-iam/token/v2/validate"
CONS.INFRA_3.AUTHENTICATION_URL_B2B = "http://ironman-kong.india.airtel.itm/b2b-iam/token/v2/validate"
CONS.INFRA_3.AUTH_READ_TIMEOUT = 10000

return CONS
