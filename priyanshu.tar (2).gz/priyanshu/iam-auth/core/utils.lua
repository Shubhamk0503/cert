--[[ 

	@author  Anmol Garg
	@description file to provide utility methods for access.lua

]]--

local json = require("cjson")
local jwt = require("resty.jwt")
local sub = string.sub
local type = type
local env_cons = require("kong.plugins.iam-auth.core.constants_environment")
local cons = require("kong.plugins.iam-auth.core.constants")



---------------------------------
-- Below method will return "empty" if string is nil ,
-- returns same otherwise
----------------------------------
function fetch_non_empty_string(str)
        if str  then
           return str
        end
    return  "empty"
end

------------------------------------
-- method to convert lua table to string
------------------------------------
function table_to_string_converter_1(o)
  if type(o) == 'table' then
     local s = '{ '
     for k,v in pairs(o) do
        if type(k) ~= 'number' then k = '"'..k..'"' end
        s = s .. '['..k..'] = ' .. table_to_string_converter_1(v) .. ','
     end
     return s .. '} '
  else
     return tostring(o)
  end
end
----------------------------------------
-- method to create http client
-- global http connection(i/o) timeout
-- is set in seconds
-----------------------------------------
function create_http_client_1(conf)
        local socket = require("socket")
        local http = require("socket.http")
        local env_cons = fetch_environment_constants_1(conf)
		local env_cons = fetch_environment_constants_1(conf)	
        local env_cons = fetch_environment_constants_1(conf)
        http.TIMEOUT = cons.AUTH_READ_TIMEOUT
        return http
end

-------------------------------------------------
-- fetching properties related to environment /PRODUCTION/INFRA_1/INFRA_2/etc
-------------------------------------------------
function fetch_environment_constants_1(conf)
	local curr_env = conf.environment_1
	return env_cons[curr_env]
end

----------------------------------------------------
-- method to fetch current time in ms
----------------------------------------------------
function get_current_time_in_ms_1()
	local _socket = require("socket")
	return math.floor(_socket.gettime()*1000)
end


---------------------------------------------------
-- method to decode and convert JWT token to JSON
---------------------------------------------------

function decode_token(conf, token)
	token = token:gsub("Bearer ", "")
	local jwt_obj = jwt:load_jwt(token)
	local decoded_token = json.encode(jwt_obj)

	return decoded_token

end
