--[[

	@author  Anmol Garg
	@description LUA script to provide configuration details for plugin ,
				 logging configuration is one of example of the same.

]]--

local function create_http_client_1(conf)
	local socket = require("socket")
        local http = require("socket.http")
        local cons = require("kong.plugins.iam-auth.core.constants")
        return http
end

-- setting up configurations in table
local __CONFIG = {}
__CONFIG["http_client"]=create_http_client_1()

-- returning final configuration table
return __CONFIG
