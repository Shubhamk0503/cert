local BasePlugin = require "kong.plugins.base_plugin"
local u = require("kong.plugins.web-auth.core.access")
local web_AuthHandler = BasePlugin:extend()

function web_AuthHandler:new()
  web_AuthHandler.super.new(self, "web-auth")
end

web_AuthHandler.PRIORITY = 2000
web_AuthHandler.VERSION = "2.0.0"

function web_AuthHandler:access(conf)
  u.execute(conf)
end

return web_AuthHandler