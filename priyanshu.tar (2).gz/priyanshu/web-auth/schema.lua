return {
  no_consumer = true,
  fields = {
  	    authenticate_only_when_headers_present = { type = "boolean", default = true },
		send_html_when_not_authorized = { type = "boolean", default = false },
		environment = {type = "string", required = true, enum = {"PROD_DC","PROD_DR","STAG"}, default = "PROD_DC"}
    }
  
  }