------------------------------ 
-- defining local variables
------------------------------
local kong_responses = kong.response
local sock = require('socket')
local http = require("resty.http")
local json = require("cjson")
local helper = require("kong.plugins.web-auth.core.helper")
local cons = require("kong.plugins.web-auth.core.constants")

local _M = {}

function _M.execute(conf)
	------------------------------
	-- logger configurations
	-------------------------------
	local logger = ngx.log
	local NGX_INFO = ngx.INFO
	local NGX_DEBUG = ngx.DEBUG
	local NGX_ERROR = ngx.ERR

	local start_time = sock.gettime()
	local request = ngx.req
	local path = ngx.var.request_uri
	logger(NGX_INFO, "In access method of web-auth !!!!")
	logger(NGX_INFO, "The uri is ---- "..path)
	if request.get_method() == "OPTIONS" then
  		logger(NGX_INFO, "It is an OPTION method call hence does not require authentication!!!!")
  	else
  		if conf.authenticate_only_when_headers_present then
            if not helper.contains_auth_token() then
                logger(NGX_INFO, "Auth header not present in request !!!!")
                logger(NGX_INFO, "Passing it directly to upstream")
                request.clear_header(cons.msisdn_header)
                logger(NGX_INFO, "Time taken by the plugin : "..sock.gettime()-start_time)
            	return
            end
        end
  		local body = {}
	  	body.token_type_hint = cons.token_hint
	  	if request.get_headers()[cons.WEB_AUTH_HEADER] then
	  		body.token = request.get_headers()[cons.WEB_AUTH_HEADER]
	  	else
	  		local v, token = pcall(helper.extract_token,request.get_headers()["cookie"])
	  		if (v and token) then
	  			body.token = token
	  		else
	  			logger(NGX_ERROR, "Can't extract token from headers "..token)
	  			logger(NGX_INFO, "Time taken by the plugin : "..sock.gettime()-start_time)
	  			helper.send_unauthenticated_response(path, conf)
	        	return
	  		end
  		end

		local body = helper.form_payload(body)
		logger(NGX_INFO,  "Payload to authorization server:: " ..  helper.fetch_non_empty_string(body))
        
        local response = {}
        local httpc = http.new()
        -- httpc:set_timeout(500)
        httpc:connect(cons.auth_server_ip[conf.environment], cons.auth_server_port[conf.environment])
		local request_time = sock.gettime()

        local res, err = httpc:request({
                method = cons.httpmethodPOST,
                path = cons.appEndPoint[conf.environment],
                headers = {
	         		["Content-Length"] = string.len(body),
	         		["Content-Type"] = cons.content_type,
	         		["Authorization"] = cons.auth_header[conf.environment]
	     		},
                body = body
            })

		logger(NGX_INFO, "Time taken to get response from auth server : "..sock.gettime()-request_time)

		if not res then
          logger(NGX_ERROR,"Request to auth server failed ".. err)
          return kong_responses.exit(504, "Auth server did not respond")
        end
       
        logger(NGX_INFO,"Authorization Response Status :: "..res.status)
        logger(NGX_INFO,"Authorization Response reason "..res.reason)

		if res.has_body then
          local body,err = res:read_body()
          logger(NGX_INFO,  "Authorization response details  :: " .. body)
          response = json.decode(body)
        else
          logger(NGX_ERROR, "No body present in auth server response!!!")
          return kong_responses.exit(401, "Authentication failed!!")
        end


		if response["iv_user"] then
			logger(NGX_INFO,  "Successfully authenticated request !!!!")
			request.set_header(cons.msisdn_header, response["iv_user"])
			logger(NGX_INFO,  "Request Headers after authentication :: "..helper.fetch_non_empty_string(json.encode(request.get_headers())))
		else
			logger(NGX_ERROR, "Authentication Failed!!!!!")
			logger(NGX_INFO, "Time taken by the plugin : "..sock.gettime()-start_time)
			helper.send_unauthenticated_response(conf)
			return
		end
  	end
	logger(NGX_INFO, "Time taken by the plugin : "..sock.gettime()-start_time)
end

return _M