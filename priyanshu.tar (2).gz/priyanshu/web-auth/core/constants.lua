local C= {}
C.token_hint = "access_token"
C.auth_server_port = {['STAG'] = 8099, ['PROD_DC'] = 8080, ['PROD_DR'] = 8080}
C.auth_server_ip = {['STAG'] = "10.5.245.56", ['PROD_DC'] = "10.5.220.52", ['PROD_DR'] = "10.5.220.52"}
C.appEndPoint = {['STAG']="/airtel-oauth/v1/oauth/introspect",['PROD_DC']="/app/wl-service/airtel-oauth/v1/oauth/introspect",['PROD_DR']="/app/wl-service/airtel-oauth/v1/oauth/introspect"}
C.auth_header = {['STAG']="Basic WlVVTF9HQVRFV0FZX1BSRVBST0Q6WkFAbGdBdDNNQF45MyNQNDBk",['PROD_DC']="Basic WlVVTF9HQVRFV0FZX1BST0Q6WlNIbWMkaEFAbGdBdDNNQCNQNDBk",['PROD_DR']="Basic WlVVTF9HQVRFV0FZX1BST0Q6WlNIbWMkaEFAbGdBdDNNQCNQNDBk"}
C.msisdn_header = "iv-user"
C.httpmethodPOST = "POST"
C.WEB_AUTH_HEADER = "z-access-token"
C.content_type = "application/x-www-form-urlencoded"
C.html_host = {['STAG']="10.5.245.57:8085",['PROD_DC']="10.5.245.57:8085",['PROD_DR']="10.5.245.57:8085"}
C.html_url = {['STAG']="/lib/html/C/selfcare-login.html",['PROD_DC']="/lib/html/C/selfcare-login.html",['PROD_DR']="/lib/html/C/selfcare-login.html"}

return C