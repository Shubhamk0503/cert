local cons = require("kong.plugins.web-auth.core.constants")
local kong_responses = kong.response               ---- for updated version of kong

local logger = ngx.log
local NGX_INFO = ngx.INFO
local NGX_DEBUG = ngx.DEBUG
local NGX_ERROR = ngx.ERR

local H = {}

function H.contains_auth_token()
	local request = ngx.req
	local json = require("cjson")
	local headers, err = request.get_headers()
	logger(NGX_INFO, "Headers extracted are :-  "..json.encode(headers or ""))
	if err == "truncated" then
		logger(NGX_INFO, "No headers retrieved from the request")
	    return false
	elseif headers[cons.WEB_AUTH_HEADER] then
		return true
	end
	return false
end

function H.extract_token(str)
	logger(NGX_INFO, "Extracting Token")
	local a = string.match(str,"PD.S.SESSION.ID=.-;")
	if a == nil then
		a = string.match(str,"PD.S.SESSION.ID=.*")
		return string.sub(a,17,-1)
	end
	return string.sub(a,17,-2)
end

function H.send_unauthenticated_response(conf)
	if conf.send_html_when_not_authorized then
		logger(NGX_INFO,  "Sending login html")
		logger(NGX_INFO,  "Redirecting to "..cons.html_host[conf.environment]..cons.html_url[conf.environment])
		ngx.req.set_method(ngx.HTTP_GET)
		ngx.var.upstream_host = cons.html_host[conf.environment]
		ngx.var.upstream_uri = cons.html_url[conf.environment]
		return
	end
	logger(NGX_ERROR,  "Authorization request failed!!!!  :: ")
	return kong_responses.exit(401, "UNAUTHORIZED ACCESS -- invalid token")
end

function H.form_payload(t)
	local s = ""
	for k, v in pairs(t) do
		s = s..k.."="..v.."&"
	end
	return string.sub(s,1,-2)
end

function H.fetch_non_empty_string(str)
        if str  then
           return str
        end
    return  "empty"
end

return H