local BasePlugin = require "kong.plugins.base_plugin"
local u = require("kong.plugins.myairtelapp-auth.core.access")
local myairtelapp_AuthHandler = BasePlugin:extend()

function myairtelapp_AuthHandler:new()
  myairtelapp_AuthHandler.super.new(self, "myairtelapp-auth")
end

myairtelapp_AuthHandler.PRIORITY = 2000
myairtelapp_AuthHandler.VERSION = "2.0.0"

function myairtelapp_AuthHandler:access(conf)
	u.execute(conf)
end

return myairtelapp_AuthHandler
