--[[

	@author  Rajat Yadav
	@description method that stores actual logic of Kong-plugin
	   			 execute is being called from handler and rest
	   			 is taken care by logic in execute method

]]--


------------------------------
-- defining local variables
------------------------------
local config = require("kong.plugins.authentication.core.c_config")
require("kong.plugins.authentication.core.utils")
local _M = {}

------------------------------
-- logger configurations
-------------------------------
local logger = ngx.log
local NGX_INFO = ngx.INFO
local NGX_DEBUG = ngx.DEBUG
local NGX_ERROR = ngx.ERR
--------------------------------


-------------------------------------------------------------------
-- Method to validate token from configured client
-- Steps
-- 1. validates token
-- 2. Creates Http Client
-- 3. Fire Http Request
-- 4. Parse response and send it to caller with authenticated flag
-- return list => is_authenticated, message, downstream_response
--------------------------------------------------------------------

local function validate_token(auth_token, machine_header, browser_header, app_id_header, conf)

	local cons = require("kong.plugins.authentication.core.constants")
	local env_cons = fetch_environment_constants(conf)
	local ltn12 = require ("ltn12")
	local json = require("cjson")
	local authentication_response = {}
	local resp = {}
	local EMPTY_STRING = ""

	if auth_token == nil or auth_token == EMPTY_STRING  then
		logger(NGX_ERROR, "Could not fetch any Authorization token.")
		return false, "Authroization token is null/blank !"
	end

	-- configuring http client
	local http = config.http_client
	http.TIMEOUT = env_cons["AUTH_READ_TIMEOUT"]

	logger(NGX_DEBUG, "About to hit authentication request at url :: " .. env_cons.AUTHENTICATION_URL)
	authentication_response["client"], authentication_response["code"],
				authentication_response["headers"], authentication_response["status"]
								= http.request{url = env_cons.AUTHENTICATION_URL, content_type = 'application/json' , sink = ltn12.sink.table(resp),
												proxy = (function() if conf.http_proxy_enabled then return cons.HTTP_PROXY else return nil end end )(),
									headers = {["Authorization"] = auth_token, ["machine"] = machine_header, ["browser"]=browser_header, ["app-id"]=app_id_header} }
	if resp ~= nil and resp ~= EMPTY_STRING then
		authentication_response["body"] = json.decode(table.concat(resp))
	end

	logger(NGX_DEBUG,  "Authorization response details  :: " ..  fetch_non_empty_string(json.encode(authentication_response["body"])))
	if authentication_response["code"] ~= nil then
		if authentication_response["code"] == cons.SUCCESS_CODE and authentication_response["body"]  ~= nil and authentication_response["body"]["authenticated"] == true then
			return true , nil , authentication_response
		end
		return false, "Downstream error occured !" ,  authentication_response
	end
	return false , "Unable to validate auth_token !"
end

----------------------------------
-- Method to authenticate header
----------------------------------
local function auhtenticate_request(conf, authorization_header, machine_header, browser_header, app_id_header)
	logger(NGX_DEBUG, "About to start authentication of token :: " .. (authorization_header or 'empty'))
	-- If no header found then request is unauthenticated
	local validated, error_message , down_stream_response  = validate_token(authorization_header, machine_header, browser_header, app_id_header, conf)
	logger(NGX_DEBUG,  "SuccessFully attempted validation for auth token ::  " .. fetch_non_empty_string(authorization_header) .. " validation status is  utils.fetch_non_empty_string(validated) ".. " error_response is " .. fetch_non_empty_string(error_response))
	if not validated then
		logger(NGX_DEBUG,  "Unable to authenticate auth token  ::" ..(authorization_header or 'empty') .. " message :: " .. (error_message or 'empty'))
		return false, error_message, down_stream_response
	end
	logger(NGX_DEBUG,  "Valid auth token ::" .. (authorization_header or 'empty') )
	return true, "Authenticcation SuccessFul !", down_stream_response
end

------------------------------------------------------------------------
-- Below method contains core logic of custom plugin
-- Steps
-- 1. Cheking schema configuration
-- 2. authenticating current request
-- 3.a. if authenticated => true then add updated authorization header to downstream request and downstream response
-- 3.b.I. otherwise if downstream service returns some response then return that response as it is.
-- 3.b.II. otherwise if downstream service does not send any response then
--         return default unauthenticated response with message
--returns response only if request is not authenticated otherwise returns downstream response with header enrichment
-------------------------------------------------------------------------
function _M.execute(conf)
    --------------------------------------------------------
    -- kong.response is new addition in PDK since, kong 1.x
    --------------------------------------------------------
    --local responses = require("kong.response")
    local kong = kong
    local request = ngx.req
    local AUTHORIZATION_HEADER_KEY = "Authorization"
    local USERPROFILEID_HEADER_KEY = "USER-ID"
    local MACHINE_HEADER_KEY = "machine"
    local BROWSER_HEADER_KEY = "browser"
    local CONSUMERID_HEADER_KEY = "x-consumer-id"
    local APP_ID_HEADER_KEY = "app-id"

    local cons = require("kong.plugins.authentication.core.constants")
	local res = ngx
	local _route = res.var.uri
  	-- proceed only if plugin is enabled
    if conf.plugin_enabled then

	-- skip in case of http options call
	local meth = request.get_method()
    logger(NGX_INFO,  "Http call method: " .. meth)

    if meth == "OPTIONS" then
            logger(NGX_INFO,  "Skip Http call as this is options call")
            return kong.response.exit(200, "Success")
    end

	-- autenticate calls
	_start_ts = get_current_time_in_ms()
	local authorization_header =  request.get_headers()[AUTHORIZATION_HEADER_KEY]
	local machine_header =  request.get_headers()[MACHINE_HEADER_KEY]
	local browser_header =  request.get_headers()[BROWSER_HEADER_KEY]
	local app_id_header =  request.get_headers()[APP_ID_HEADER_KEY]

    local is_authenticated, error_message , down_stream_response = auhtenticate_request(conf, authorization_header, machine_header, browser_header, app_id_header)
	_end_ts = get_current_time_in_ms()
	logger(NGX_INFO, "Time taken by plugin to authenticate request " .. (_end_ts - _start_ts ) .. " ms.")

         -- if request is not authenticated then handle it
	if is_authenticated ~= true then
		logger(NGX_ERROR, "Unable to authenticate token " .. fetch_non_empty_string(authorization_header) .. " for route " .. _route)

		-- if downstream error occured then send response as it is
		if down_stream_response then
			logger(NGX_ERROR, "down stream response " .. table_to_string_converter(down_stream_response["body"]))
			return kong.response.exit(down_stream_response["code"], down_stream_response["body"] , conf.unauthenticated_response_headers)
		end

		-- if unauthenticated due to validationns in plugin
        local error_response = cons.UNAUTHENTICATED_DEFAULT_RESPONSE
		if error_message then
        	error_response.message = error_message
		end

		return kong.response.exit(conf.unauthenticated_response_status_code, error_response , conf.unauthenticated_response_headers)
     end

    logger(NGX_INFO, "SuccessFully authenticated token :: " .. fetch_non_empty_string(authorization_header) .. " for route " .. _route)

    --user is succesfully authenticated, check if userProfileId and token in down stream respons is null
    if down_stream_response["body"] ~= nil and (down_stream_response["body"]["token"] == nil
      or down_stream_response["body"]["userProfileId"] == nil)  then
      logger(NGX_ERROR, "down stream response - token or profile id is nil" ..  table_to_string_converter(down_stream_response["body"]))
      return kong.response.exit(down_stream_response["code"], down_stream_response["body"] , conf.unauthenticated_response_headers)
    end

    -- user is successfully authenticated then updating header in request for downstream call
	if down_stream_response["body"] ~= nil and down_stream_response["body"]["token"] ~= nil
      and down_stream_response["body"]["userProfileId"] ~= nil then
		logger(NGX_INFO, "Updated token  against old token " .. authorization_header .. " is :: " .. down_stream_response["body"]["token"])

		-- setting up authorization header in request
		request.get_headers()[AUTHORIZATION_HEADER_KEY] = down_stream_response["body"]["token"]
    request.set_header(USERPROFILEID_HEADER_KEY, down_stream_response["body"]["userProfileId"])
    request.set_header(CONSUMERID_HEADER_KEY, down_stream_response["body"]["userProfileId"])

		-- setting up response header
		res.header[AUTHORIZATION_HEADER_KEY] = down_stream_response["body"]["token"]
	end
end
end




return _M
