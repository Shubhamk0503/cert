local token_hint = "app_token"
local auth_server = {["STAG"]="http://10.5.245.56:8099/airtel-oauth/v1/oauth/introspect",["PROD_DC"]="http://10.5.220.52:8080/app/wl-service/airtel-oauth/v1/oauth/introspect",["PROD_DR"]="http://10.5.220.52:8080/app/wl-service/airtel-oauth/v1/oauth/introspect"}
local auth_header = {["STAG"]="Basic WlVVTF9HQVRFV0FZX1BSRVBST0Q6WkFAbGdBdDNNQF45MyNQNDBk",["PROD_DC"]="Basic WlVVTF9HQVRFV0FZX1BST0Q6WlNIbWMkaEFAbGdBdDNNQCNQNDBk",["PROD_DR"]="Basic WlVVTF9HQVRFV0FZX1BST0Q6WlNIbWMkaEFAbGdBdDNNQCNQNDBk"}
local S2S_Z_AUTH_KEY = "z-auth-key"
local secretKeyMyAirtelApp = "JUb2tlbiIsImNsaWVudElkIjoidWIiOiJUb2tlbiIsImNsaWVudElkIjoiUEFZV0iLCJp"

local MSIDN = "iv-user"
local request = ngx.req

local multipart_header = "multipart"

local client_auth_corrId = "x-client-auth-correlationId"

local logger = ngx.log
local NGX_INFO = ngx.INFO
local NGX_DEBUG = ngx.DEBUG
local NGX_ERROR = ngx.ERR

local function fetch_non_empty_string(str)
        if str  then
           return str
        end
    return  "empty"
end

local function form_payload(t)
	local s = ""
	for k, v in pairs(t) do
		s = s..k.."="..v.."&"
	end
	return string.sub(s,1,-2)
end

local function starts_with(str, start)
	logger(NGX_INFO, "Checking the beginning of uri")
   	return string.sub(str,1, #start) == start
end

local function generateRandomString()
        local chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-={}|[]`~'
        local length = 40
        local randomString = ''

        math.randomseed(os.time())

        local charTable = {}
        for c in chars:gmatch"." do
            table.insert(charTable, c)
        end

        for i = 1, length do
            randomString = randomString .. charTable[math.random(1, #charTable)]
        end

        return randomString
end

local function my_airtel_request()
	logger(NGX_INFO, "in my_airtel_request function")
	local json = require("cjson")
	local headers, err = request.get_headers()
	logger(NGX_INFO, "Headers extracted are :-  "..json.encode(headers or ""))
	if err == "truncated" then
    	logger(NGX_INFO, "No headers retrieved from the request")
    	return false
	elseif headers["x-bsy-did"] and headers["x-bsy-dt"] and headers["x-bsy-utkn"] then
		return true
	end
	return false
end

local function set_request_headers(path, msidn)
	logger(NGX_INFO, "Setting Headers")
	request.set_header(MSIDN, msidn)
	request.set_header(S2S_Z_AUTH_KEY, secretKeyMyAirtelApp)
	request.set_header(client_auth_corrId, generateRandomString())
end

local function multipart_request(header)
  logger(NGX_INFO,"Checking whether it is a multipart request")
  return starts_with(header, multipart_header)
end

local utils = {}
utils.token_hint = token_hint
utils.auth_server = auth_server
utils.auth_header = auth_header
utils.fetch_non_empty_string = fetch_non_empty_string
utils.form_payload = form_payload
utils.my_airtel_request = my_airtel_request
utils.set_request_headers = set_request_headers
utils.multipart_request = multipart_request

return utils