local C= {}
C.OPTION = "OPTIONS"
C.APP_AUTH_HEADER_X_BSY_ATKN = "x-bsy-atkn"
C.APP_AUTH_HEADER_X_BSY_DATE = "x-bsy-date"
C.APP_AUTH_HEADER_X_BSY_DT = "x-bsy-dt"
C.APP_AUTH_HEADER_X_BSY_DID = "x-bsy-did"
C.APP_AUTH_HEADER_X_BSY_UTKN = "x-bsy-utkn"
C.APP_AUTH_HEADER_X_CLIENT = "x-client"
C.appEndPoint = "/myairtelapp/v1/commons/authorizeUser"

------------------------------
	-- staging properties
------------------------------
-- C.appURI = "http://10.5.204.30:8585/myairtelapp/v1/commons/authorizeUser"
-- C.appId = "3bfc7bbb83cd287525feec18ceae49e1"
-- C.secretKey = "7c891a57778eb08926aaa51f65e18a27"
C.appIP = {['STAG']="10.5.204.30",['PROD_DC']='10.5.221.145',['PROD_DR']="10.14.98.136"}
C.appPort = {['STAG']=8585,['PROD_DC']=80,['PROD_DR']=80}

C.appId = {['STAG']='3bfc7bbb83cd287525feec18ceae49e1',['PROD_DC']='fdd38674b4320ed3513741e35af7a508',['PROD_DR']='fdd38674b4320ed3513741e35af7a508'}
C.secretKey = {['STAG']='7c891a57778eb08926aaa51f65e18a27',['PROD_DC']='3ea7d00d2afcc9d59805712adc784149',['PROD_DR']='3ea7d00d2afcc9d59805712adc784149'}

------------------------------
	-- production properties
------------------------------
-- C.appId="fdd38674b4320ed3513741e35af7a508"
-- C.secretKey="3ea7d00d2afcc9d59805712adc784149"
-- C.appURI = "http://10.5.221.95:80/myairtelapp/v1/commons/authorizeUser"

C.appXClient = "aw"
C.COLON = ":"
C.httpRequestMethod = "m"
C.httpRequestUri = "u"
C.payload = "d"
C.headers = "h"
C.userId = "uid"
C.httpmethodPOST = "POST"
C.content_type = "application/json"
C.multipart_header = "multipart"
C.APP_SERVER_ERROR = {["ErrorCode"] = "APP_SERVER_ERROR", ["ErrorMessage"] = "Business error from App server while authenticated."}
C.APP_INTERNAL_SERVER_ERROR = {["ErrorCode"] = "APP_INTERNAL_SERVER_ERROR", ["ErrorMessage"] = "Exception from App server while authenticating."}

C.MSIDN = "iv-user"
C.S2S_Z_AUTH_KEY = "z-auth-key"
C.secretKeyMyAirtelApp = "JUb2tlbiIsImNsaWVudElkIjoidWIiOiJUb2tlbiIsImNsaWVudElkIjoiUEFZV0iLCJp"

C.client_auth_corrId = "x-client-auth-correlationId"

return C
