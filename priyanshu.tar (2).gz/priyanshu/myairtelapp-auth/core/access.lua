------------------------------
-- defining local variables
------------------------------
local kong_responses = kong.response               ---- for updated version of kong
local sock = require('socket')
local json = require("cjson")
local http = require("resty.http")
local helper = require("kong.plugins.myairtelapp-auth.core.helper")
local cons = require("kong.plugins.myairtelapp-auth.core.constants")
local _M = {}

function _M.execute(conf)
    ------------------------------
    -- logger configurations
    -------------------------------
    local logger = ngx.log
    local NGX_INFO = ngx.INFO
    local NGX_DEBUG = ngx.DEBUG
    local NGX_ERROR = ngx.ERR

    local start_time = sock.gettime()
    local request = ngx.req
    local path = ngx.var.request_uri
    logger(NGX_INFO, "In access method of app-auth !!!!")
    logger(NGX_INFO, "The uri is ---- "..path)
    if request.get_method() == cons.OPTION then
        logger(NGX_INFO, "It is an OPTION method call hence does not require authentication!!!!")
    else
        if conf.authenticate_only_when_headers_present then
            if not helper.my_airtel_request() then
                logger(NGX_INFO, "This is not myairtelapp request !!!!")
                logger(NGX_INFO, "Passing it directly to upstream")
                logger(NGX_INFO, "Time taken by the plugin : "..sock.gettime()-start_time)
            return
            end
        end

        local request_headers, err = request.get_headers()
        if err == "truncated" then
            logger(NGX_INFO, "No headers retrieved from the request")
            logger(NGX_INFO, "Time taken by the plugin : "..sock.gettime()-start_time)
            return kong_responses.exit(400,"No headers present")
        end
        local utkn = helper.split(request_headers[cons.APP_AUTH_HEADER_X_BSY_UTKN],cons.COLON)
        if helper.tablelength(utkn) < 2 then
            logger(NGX_INFO, "Utkn header invalid")
            logger(NGX_INFO, "Time taken by the plugin : "..sock.gettime()-start_time)
            return kong_responses.exit(400, "utkn not valid")
        end
        local headers = {
            [cons.APP_AUTH_HEADER_X_BSY_UTKN] = request_headers[cons.APP_AUTH_HEADER_X_BSY_UTKN] or "",
            [cons.APP_AUTH_HEADER_X_BSY_DT] = request_headers[cons.APP_AUTH_HEADER_X_BSY_DT] or "",
            [cons.APP_AUTH_HEADER_X_BSY_DID] = request_headers[cons.APP_AUTH_HEADER_X_BSY_DID] or ""
        }
        request.read_body()
        local payload_to_auth = {
            [cons.httpRequestMethod] = request.get_method(),
            [cons.httpRequestUri] = path,
            [cons.payload] = request.get_body_data() or "",
            [cons.headers] = headers,
            [cons.userId] = utkn[1]
        }
        if request_headers['content-type'] and helper.multipart_request(request_headers['content-type']) then
            logger(NGX_INFO, "Deleting d from payload")
            payload_to_auth[cons.payload] = nil
        end
        payload_to_auth = json.encode(payload_to_auth)
        logger(NGX_INFO, "Payload to auth is --- "..payload_to_auth)
        local timestamp = math.floor(sock.gettime()*1000)
        local signature = helper.generateSignature(cons.secretKey[conf.environment],cons.httpmethodPOST..cons.appEndPoint..payload_to_auth..timestamp)
        local header_to_auth = {
            [cons.APP_AUTH_HEADER_X_BSY_DT] = request_headers[cons.APP_AUTH_HEADER_X_BSY_DT] or "",
            [cons.APP_AUTH_HEADER_X_BSY_DID] = request_headers[cons.APP_AUTH_HEADER_X_BSY_DID] or "",
            [cons.APP_AUTH_HEADER_X_BSY_DATE] = tostring(timestamp),
            [cons.APP_AUTH_HEADER_X_CLIENT] = cons.appXClient,
            [cons.APP_AUTH_HEADER_X_BSY_ATKN] = cons.appId[conf.environment]..cons.COLON..signature,
            ["Content-Type"] = cons.content_type,
            ["Content-Length"] = string.len(payload_to_auth)
        }
        logger(NGX_ERROR, "Headers to auth are --- "..json.encode(header_to_auth))

        local response={}
        local httpc = http.new()
        -- httpc:set_timeout(500)
        httpc:connect(cons.appIP[conf.environment], cons.appPort[conf.environment])

        local request_time = sock.gettime()
        local res, err = httpc:request({
                method = cons.httpmethodPOST,
                path = cons.appEndPoint,
                headers = header_to_auth,
                body = payload_to_auth
            })
        
        logger(NGX_INFO, "Time taken to get response from auth server : "..sock.gettime()-request_time)

        if not res then
          logger(NGX_ERROR,"Request to auth server failed ".. err)
          return kong_responses.exit(400, "Auth server did not respond")
        end
       
        logger(NGX_INFO,"Authorization Response Status :: "..res.status)
        logger(NGX_INFO,"Authorization Response reason "..res.reason)

        if (res.status>=400 and res.status<500) then
            logger(NGX_INFO,"Recieved 4xx from server")
            logger(NGX_INFO, "Time taken by the plugin : "..sock.gettime()-start_time)
            return kong_responses.exit(res.status,cons.APP_SERVER_ERROR)
        elseif (res.status >= 500) then
            logger(NGX_INFO,"Recieved 5xx from server")
            logger(NGX_INFO, "Time taken by the plugin : "..sock.gettime()-start_time)
            return kong_responses.exit(res.status,cons.APP_INTERNAL_SERVER_ERROR)
        end

        if res.has_body then
          body,err = res:read_body()
          logger(NGX_INFO,  "Authorization response details  :: " .. body)
          response = json.decode(body)
        else
          logger(NGX_ERROR, "No body present in auth server response!!!")
          return kong_responses.exit(401, "Authentication failed!!")
        end

        if (res.status==200 and response["data"]["validUser"]) then
            logger(NGX_INFO,"Successfully authenticated request")
            helper.set_request_headers(response["data"]["primaryMsisdn"])
            logger(NGX_INFO,  "Request Headers after authentication :: "..json.encode(request.get_headers()))
        else
            logger(NGX_ERROR,  "Authorization request failed!!!!  :: ")
            logger(NGX_INFO, "Time taken by the plugin : "..sock.gettime()-start_time)
            return kong_responses.exit(res.status, response)
        end
    end
    logger(NGX_INFO, "Time taken by the plugin : "..sock.gettime()-start_time)

end

return _M
