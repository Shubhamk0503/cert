local cons = require("kong.plugins.myairtelapp-auth.core.constants")
local hmac = require "resty.hmac"
local base64 = require "base64"
local logger = ngx.log
local NGX_INFO = ngx.INFO
local NGX_DEBUG = ngx.DEBUG
local NGX_ERROR = ngx.ERR
local request = ngx.req

local function generateRandomString()
        local chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-={}|[]`~'
        local length = 40
        local randomString = ''

        math.randomseed(os.time())

        local charTable = {}
        for c in chars:gmatch"." do
            table.insert(charTable, c)
        end

        for i = 1, length do
            randomString = randomString .. charTable[math.random(1, #charTable)]
        end

        return randomString
end

local function starts_with(str, start)
  return string.sub(str,1, #start) == start
end

local H ={}

function H.split(pString, pPattern)
   local Table = {}  -- NOTE: use {n = 0} in Lua-5.0
   local fpat = "(.-)" .. pPattern
   local last_end = 1
   local s, e, cap = pString:find(fpat, 1)
   while s do
      if s ~= 1 or cap ~= "" then
     table.insert(Table,cap)
      end
      last_end = e+1
      s, e, cap = pString:find(fpat, last_end)
   end
   if last_end <= #pString then
      cap = pString:sub(last_end)
      table.insert(Table, cap)
   end
   return Table
end

function H.tablelength(T)
  local count = 0
  for _ in pairs(T) do count = count + 1 end
  return count
end

function H.generateSignature(s_key,plaintext)
  logger(NGX_INFO,"plaintext -- "..plaintext)
  logger(NGX_INFO,"secret key -- "..s_key)
  local hm, err = hmac:new(s_key)
  local sig, err = hm:generate_signature("sha1", plaintext)
  logger(NGX_INFO,"Signature -- "..sig)
  return sig
end

function H.my_airtel_request()
  local json = require("cjson")
  local headers, err = request.get_headers()
  logger(NGX_INFO, "Headers extracted are :-  "..json.encode(headers or ""))
  if err == "truncated" then
      logger(NGX_INFO, "No headers retrieved from the request")
      return false
  elseif headers[cons.APP_AUTH_HEADER_X_BSY_DID] and headers[cons.APP_AUTH_HEADER_X_BSY_DT] and headers[cons.APP_AUTH_HEADER_X_BSY_UTKN] then
    return true
  end
  return false
end

function H.set_request_headers(msidn)
  logger(NGX_INFO, "Setting Headers")
  request.set_header(cons.MSIDN, msidn)
  request.set_header(cons.S2S_Z_AUTH_KEY, cons.secretKeyMyAirtelApp)
  request.set_header(cons.client_auth_corrId, generateRandomString())
end

function H.multipart_request(header)
  logger(NGX_INFO,"Checking whether it is a multipart request")
  return starts_with(header, cons.multipart_header)
end
return H
