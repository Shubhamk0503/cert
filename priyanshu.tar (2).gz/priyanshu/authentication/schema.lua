--[[

	@author  Rajat Yadav
	@description LUA script to provide schema details for plugin ,
	             it can be changed dynamically from Kong Admin Platform

]]--



return {
  no_consumer = true,
  fields = {

   		http_proxy_enabled = { type = "boolean", default = true },
		plugin_enabled = { type = "boolean", default = true },
		unauthenticated_response_status_code = {type = "number", default = 401},
		unauthenticated_response_headers = { type = "array", default = nil},
		environment = {type = "string", required = true, enum = {"PROD", "TECH_INFRA_1", "TECH_INFRA_2", "TECH_INFRA_3"}}
    }

  }


