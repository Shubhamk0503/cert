**Custom Authentication Plugin**
-------------------

Description ::
----
Plugin which intercepts incoming request and authenticates the same and if request is authenticated then pass flow to downstream otherwise unauthenticate request.

Dependencies (Installation Commands)::
----
1. > luarocks (yum install luarocks)
1. > lua-cjson (luarocks install lua-cjson)
1. > luasocket (luarocks install luasocket)

Basic Requirements For Custom Plugins ::
----
1. > handler.lua - (Defines and registers plugin to kong)
1. > schema.lua - (Defines code configuration)
1. > access.lua - (Contains business rules)
1. > Entry for custom-plugins in **$KONG_DIR**/templates/kong_defaults.lua is must
1. > Depending on library usage **LUA_PATH and LUA_CPATH** environment variables must be initialized and exported

eg :: (Developing custom plugin) [hello-world plugin](https://streamdata.io/blog/developing-an-helloworld-kong-plugin/)

Work Flow ::
----
Please open auth_plugin_seq_diag.xml on [draw.io](https://www.draw.io/) to check sequence diagram

