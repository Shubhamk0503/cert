--[[

	@author  Rajat Yadav
	@description LUA script to handler of custom plugin
				 logic is placed inside access.execute
				 method of access script.

]]--


local BasePlugin = require "kong.plugins.base_plugin"
local access = require "kong.plugins.authentication.core.access"
local AuthHandler = BasePlugin:extend()


function AuthHandler:new()
  AuthHandler.super.new(self, "authentication")
end

AuthHandler.PRIORITY = 1500
AuthHandler.VERSION = "2.0.0"


function AuthHandler:access(conf)
  AuthHandler.super.access(self)
  access.execute(conf)
end

return AuthHandler

