--[[

	@author  Rajat Yadav
	@description LUA script to provide configuration details for plugin ,
				 logging configuration is one of example of the same.

]]--

local function create_http_client(conf)
	local socket = require("socket")
        local http = require("socket.http")
        local cons = require("kong.plugins.authentication.core.constants")
        return http
end

-- setting up configurations in table
local _CONFIG = {}
_CONFIG["http_client"]=create_http_client()

-- returning final configuration table
return _CONFIG
