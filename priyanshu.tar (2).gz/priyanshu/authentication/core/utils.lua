--[[ 

	@author  Rajat Yadav
	@description file to provide utility methods for access.lua

]]--


---------------------------------
-- Below method will return "empty" if string is nil , 
-- returns same otherwise
----------------------------------
function fetch_non_empty_string(str)
        if str  then
           return str
        end
    return  "empty"
end

------------------------------------
-- method to convert lua table to string 
------------------------------------
function table_to_string_converter(o)
   if type(o) == 'table' then
      local s = '{ '
      for k,v in pairs(o) do
         if type(k) ~= 'number' then k = '"'..k..'"' end
         s = s .. '['..k..'] = ' .. table_to_string_converter(v) .. ','
      end
      return s .. '} '
   else
      return tostring(o)
   end
end
----------------------------------------
-- method to create http client 
-- global http connection(i/o) timeout
-- is set in seconds
-----------------------------------------
function create_http_client(conf)
	local socket = require("socket")
	local http = require("socket.http")
	local cons = require("kong.plugins.authentication.core.constants")
	local env_cons = fetch_environment_constants(conf)	
	http.TIMEOUT = env_cons.AUTH_READ_TIMEOUT
	return http
end

-------------------------------------------------
-- fetching properties related to environment /prod/tech_infra_1/tech_infra_2/etc
-------------------------------------------------
function fetch_environment_constants(conf)
	local env_cons = require("kong.plugins.authentication.core.constants_environment")
	local curr_env = conf.environment
	return env_cons[curr_env]
end

----------------------------------------------------
-- method to fetch current time in ms
----------------------------------------------------
function get_current_time_in_ms()
	local _socket = require("socket")
	return math.floor(_socket.gettime()*1000)
end
