------------------------------------------
-- @author - Rajat Yadav
-- @description - File to store static properties
-- which does not depend on environment
------------------------------------------------



C = {}

-- proxy constants
C.HTTP_PROXY = os.getenv("http_proxy")

-- authentication constants
C.SUCCESS_CODE = 200
C.UNAUTHENTICATED_CODE = 401
C.AUTHORIZATION_HEADER_KEY = "Authorization"
C.UNAUTHENTICATED_DEFAULT_RESPONSE = {["authenticated"] = false,["token"] = nil , ["message"]= "user is not authenticated"}

return C


