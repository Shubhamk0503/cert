C = {}

C.PROD = {}
C.PROD.AUTHENTICATION_URL = "http://digi-api.airtel.in:8000/team-iam/v1/token/validate"
C.PROD.AUTH_READ_TIMEOUT = 10

C.TECH_INFRA_1 = {}
C.TECH_INFRA_1.AUTHENTICATION_URL = "http://10.5.74.73:8021/team-iam/v1/token/validate"
C.TECH_INFRA_1.AUTH_READ_TIMEOUT = 10

C.TECH_INFRA_2 = {}
C.TECH_INFRA_2.AUTHENTICATION_URL = "http://10.5.74.73:8021/team-iam/v1/token/validate"
C.TECH_INFRA_2.AUTH_READ_TIMEOUT = 10

C.TECH_INFRA_3 = {}
C.TECH_INFRA_3.AUTHENTICATION_URL = "http://10.5.74.73:8021/team-iam/v1/token/validate"
C.TECH_INFRA_3.AUTH_READ_TIMEOUT = 10

return C
