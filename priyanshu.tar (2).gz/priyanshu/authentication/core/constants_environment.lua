C = {}

C.PROD = {}
C.PROD.AUTHENTICATION_URL = "http://internalapi-gateway.india.airtel.itm:8080/team-iam/token/v2/validate"
C.PROD.AUTH_READ_TIMEOUT = 10

C.TECH_INFRA_1 = {}
C.TECH_INFRA_1.AUTHENTICATION_URL = "http://internalapi-gateway.india.airtel.itm:8080/team-iam/token/v2/validate"
C.TECH_INFRA_1.AUTH_READ_TIMEOUT = 10

C.TECH_INFRA_2 = {}
C.TECH_INFRA_2.AUTHENTICATION_URL = "http://internalapi-gateway.india.airtel.itm:8080/team-iam/token/v2/validate"
C.TECH_INFRA_2.AUTH_READ_TIMEOUT = 10

C.TECH_INFRA_3 = {}
C.TECH_INFRA_3.AUTHENTICATION_URL = "http://internalapi-gateway.india.airtel.itm:8080/team-iam/token/v2/validate"
C.TECH_INFRA_3.AUTH_READ_TIMEOUT = 10

return C
